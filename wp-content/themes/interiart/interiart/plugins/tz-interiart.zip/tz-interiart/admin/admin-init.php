<?php
    require_once PLUGIN_SERVER_PATH.'/admin/post-type/function-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/vc-extension/vc-init.php';
    require_once PLUGIN_SERVER_PATH.'/admin/shortcode/function_shortcode.php';

/*
 * Required: widget contact info
 */
require_once PLUGIN_SERVER_PATH . '/admin/widgets/contact-info.php';

/*
    * Required: widget lastest project
    */
require_once PLUGIN_SERVER_PATH . '/admin/widgets/latest-project.php';

/*
    * Required: widget recent post
    */
require_once PLUGIN_SERVER_PATH . '/admin/widgets/recent-post.php';

?>